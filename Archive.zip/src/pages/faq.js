import React from 'react';

export default function FAQ() {
  return (
    <div>
      <h1 className="header-title">Hello FAQ</h1>
    </div>
  );
}
