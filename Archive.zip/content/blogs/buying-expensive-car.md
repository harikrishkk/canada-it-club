---
title: Buying expensive cars
subtitle: Shall I buy a new one? Or lease one?
date: 2022-08-01
slug: buying-expensive-cars
author: Sudheer
---
## Brother, should I buy an expensive car?

One of the most common mistakes people do after landing in Canada is that they get an expensive car before they purchase a house. Since it is easy to get a car in lease/finance, lot of people go for that. 

This is purely from mine & others experience who got into trouble. My strong advise to everyone who is landing in Canada is that, DO NOT purchase an expensive car during the first year. CAR is not an asset. Its a depreciating asset. Whether it is finance/leased, it is not worth. 

### Here are the cons of purchasing an expensive car: 

1. It's value will depreciate very quickly
2. The auto insurance is very high since your previous experience may not be taken into consideration
3. Monthly auto payment (lease + auto insurance + gas + maintenance) will be very high
4. Having a car lease/loan will affect your mortgage eligibility when purchasing a house
5. You will get fed up paying for a car for 5-7 years


### There are 2 ways to tackle this. 

1. Use public transport. Use Uber whenever required. You will still be paying less than maintaining a car.
2. Purchase a cheap car (less than 7000$). After purchasing a house, go for a better car. 

Once you are settled and you are good with enough cash flow, you can make a decision to upgrade. 



