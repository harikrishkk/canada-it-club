---
title: Is hiring frozen
subtitle: I bet you would have heard or thought this once
date: 2022-08-03
slug: is-hiring-frozen
author: Sudheer
---
## Is hiring frozen?

I have heard this a lot. 
But is it 100% correct? 

**No.**

This might be true in USA, but not in Canada. In USA, they have thanksgiving holiday in Nov end and Xmas holidays in Dec end. Most of the companies have year ending in Dec, hence their hiring will be reduced in Nov/Dec end. 

In Canada, the banks (major hiring in Toronto) have Financial Year starting by Nov 1st. Hence they continue hiring through Nov/Dec. It may be slow, but there will be lot of opportunities in Nov/Dec. 

Hence do not wait until January to start a job search.
The market is up and there are opportunities available. 

Good luck everyone...